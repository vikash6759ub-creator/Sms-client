package com.example.smsclient

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import okhttp3.*
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

class WebSocketClient private constructor(private val context: Context) {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(30, TimeUnit.SECONDS)
        .build()
    private var webSocket: WebSocket? = null
    private val gson = Gson()
    private val prefs = context.getSharedPreferences("sms_prefs", Context.MODE_PRIVATE)

    private val deviceId: String
        get() {
            var id = prefs.getString("device_id", null)
            if (id == null) {
                id = java.util.UUID.randomUUID().toString()
                prefs.edit().putString("device_id", id).apply()
            }
            return id
        }

    init {
        connect()
    }

    private fun connect() {
        // 🔴 LIVE WORKER URL - यहाँ अपना असल worker URL डालो
        val request = Request.Builder()
            .url("wss://sms-tracker-worker.vikash6759ub.workers.dev/ws/device?deviceId=$deviceId")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d("WebSocket", "Connected")
                val registerMsg = mapOf("type" to "register", "deviceId" to deviceId)
                webSocket.send(gson.toJson(registerMsg))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                Log.d("WebSocket", "Received: $text")
                try {
                    val command = gson.fromJson(text, Map::class.java)
                    handleCommand(command)
                } catch (e: Exception) {
                    Log.e("WebSocket", "JSON error", e)
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d("WebSocket", "Closing: $reason")
                webSocket.close(1000, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e("WebSocket", "Error", t)
                reconnect()
            }
        })
    }

    private fun reconnect() {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            connect()
        }, 5000)
    }

    private fun handleCommand(command: Map<*, *>) {
        val type = command["type"] as? String
        when (type) {
            "send_sms" -> {
                val phoneNumber = command["phoneNumber"] as? String
                val message = command["message"] as? String
                if (phoneNumber != null && message != null) {
                    SmsSender.sendSms(context, phoneNumber, message)
                }
            }
            "bulk_sms" -> {
                val numbers = command["numbers"] as? List<*>
                val message = command["message"] as? String
                val batchId = command["batchId"] as? String
                if (numbers != null && message != null && batchId != null) {
                    SmsSender.sendBulkSms(context, numbers.filterIsInstance<String>(), message, batchId)
                }
            }
        }
    }

    fun sendData(data: Map<String, Any>) {
        val fullData = data.toMutableMap()
        fullData["deviceId"] = deviceId
        val json = gson.toJson(fullData)
        webSocket?.send(json)
    }

    companion object {
        @Volatile
        private var instance: WebSocketClient? = null

        fun getInstance(context: Context): WebSocketClient {
            return instance ?: synchronized(this) {
                instance ?: WebSocketClient(context.applicationContext).also { instance = it }
            }
        }
    }
}