package com.example.smsclient

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import androidx.work.*

class BatteryReader(private val context: Context) {

    fun getBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    class BatteryWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
        override fun doWork(): Result {
            val level = BatteryReader(applicationContext).getBatteryLevel()
            WebSocketClient.getInstance(applicationContext).sendData(mapOf(
                "type" to "battery",
                "level" to level,
                "timestamp" to System.currentTimeMillis()
            ))
            return Result.success()
        }
    }

    companion object {
        fun schedulePeriodicUpdates(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<BatteryWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "battery_updates",
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}