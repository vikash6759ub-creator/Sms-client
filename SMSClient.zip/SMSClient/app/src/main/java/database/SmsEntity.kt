package com.example.smsclient.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pending_sms")
data class SmsEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val phoneNumber: String,
    val message: String,
    val batchId: String?,
    val status: String,
    val timestamp: Long
)