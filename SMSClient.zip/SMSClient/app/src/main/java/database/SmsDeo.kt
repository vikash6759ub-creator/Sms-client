package com.example.smsclient.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Dao
interface SmsDao {
    @Insert
    suspend fun insert(sms: SmsEntity)

    @Query("SELECT * FROM pending_sms WHERE status = 'pending' ORDER BY timestamp ASC")
    suspend fun getPending(): List<SmsEntity>

    @Delete
    suspend fun delete(sms: SmsEntity)
}