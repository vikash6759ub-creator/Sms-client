package com.example.smsclient

import android.content.Context
import android.telephony.SmsManager
import android.util.Log
import androidx.work.*
import com.example.smsclient.database.AppDatabase
import com.example.smsclient.database.SmsEntity
import kotlinx.coroutines.*

object SmsSender {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val smsManager = SmsManager.getDefault()

    fun sendSms(context: Context, phoneNumber: String, message: String, batchId: String? = null) {
        scope.launch {
            try {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
                Log.d("SmsSender", "SMS sent to $phoneNumber")
                if (batchId != null) {
                    WebSocketClient.getInstance(context).sendData(mapOf(
                        "type" to "sms_status",
                        "batchId" to batchId,
                        "number" to phoneNumber,
                        "status" to "sent",
                        "reason" to ""
                    ))
                }
            } catch (e: Exception) {
                Log.e("SmsSender", "Failed to send to $phoneNumber", e)
                val reason = when (e) {
                    is SecurityException -> "permission denied"
                    is IllegalArgumentException -> "invalid number"
                    else -> "network error"
                }
                if (batchId != null) {
                    WebSocketClient.getInstance(context).sendData(mapOf(
                        "type" to "sms_status",
                        "batchId" to batchId,
                        "number" to phoneNumber,
                        "status" to "failed",
                        "reason" to reason
                    ))
                }
            }
        }
    }

    fun sendBulkSms(context: Context, numbers: List<String>, message: String, batchId: String) {
        scope.launch {
            val batchSize = 5
            val batches = numbers.chunked(batchSize)

            batches.forEachIndexed { batchIndex, batch ->
                // Gap between batches
                if (batchIndex > 0) {
                    delay(8000) // 8 seconds between batches
                }

                batch.forEachIndexed { index, number ->
                    if (index > 0) delay(1000) // 1 second between numbers
                    sendSms(context, number, message, batchId)
                }
            }
        }
    }

    fun savePendingSms(context: Context, phoneNumber: String, message: String, batchId: String?) {
        val db = AppDatabase.getInstance(context)
        val entity = SmsEntity(
            phoneNumber = phoneNumber,
            message = message,
            batchId = batchId,
            status = "pending",
            timestamp = System.currentTimeMillis()
        )
        scope.launch {
            db.smsDao().insert(entity)
        }
    }

    fun retryPendingSms(context: Context) {
        scope.launch {
            val db = AppDatabase.getInstance(context)
            val pending = db.smsDao().getPending()
            pending.forEach { sms ->
                sendSms(context, sms.phoneNumber, sms.message, sms.batchId)
                db.smsDao().delete(sms)
            }
        }
    }
}